package com.hcl.hclassessment2.cartmanagement;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@org.springframework.stereotype.Component
public class Component {
    @SpringBootApplication
}
